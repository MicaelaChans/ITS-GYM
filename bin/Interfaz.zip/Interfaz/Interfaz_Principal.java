package Interfaz;

public class Interfaz_Principal {

	public static void main(String[] args) {
		 new Ventana_Principal().setVisible(true);
	}

}
