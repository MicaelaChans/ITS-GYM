package Interfaz;

public class ReferenteAdulto {
    private String ci;
    private String nombre;
    private String telefono;

    public ReferenteAdulto(String ci, String nombre, String telefono) {
        this.ci = ci;
        this.nombre = nombre;
        this.telefono = telefono;
    }
}
